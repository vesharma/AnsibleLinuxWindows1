#!/bin/sh

#if out=`ansible-playbook backyp.yml -i invt.txt --extra-vars 'ansible_user=root ansible_password=redhat@1`; then echo $out; fi'`

if !out=`ansible-playbook /root/ProjectScript/PJ1/backyp.yml -i invt.txt --extra-vars 'ansible_user=root ansible_password=redhat@1'`; then echo $out; fi;
